%Código Carla Beatriz 2024
%Projeto de Filtros Digitais IIR

pkg load signal;
[x,fa]=audioread('C:\Users\Administrador\Downloads\fala_sirene_tm3.wav');%carrega o arquivo de audio.
sound(x,fa);%executa o arquivo de audio.
figure;
plot(x);%Plotagem do vetor.

X=fft(x);%transformada do vetor X.
Tam=length(X);%tamanho do vetor X.
X=X/(Tam/2);%normalização do vetor.
f=[0:Tam-1]*fa/(Tam-1);%Criando o vetor da frequencia.
plot(f(1:Tam/2),abs(X(1:Tam/2)));%Plotagem do vetor.

%FILTRO NOTCH
omegac=(2*pi*250)/fa;%Normalizando a frequencia de corte.
r=0.996;%Qualidade do sinal.
b=[1 -2*cos(omegac) 1];%Coeficiente do numerador.
a=[1 -2*r*cos(omegac) r^2];%Coeficiente do denominador.
hold on;%Plotar no gráfico sem fechar o anterior.
[H,W]=freqz(b,a,Tam,fa);%Resposta em frequencia do filtro Notch.
plot(W,abs(H));%Plotagem do filtro Notch.

%FILTRAGEM
y=filter(b,a,x);%Filtrando o sinal com a função.
Y=fft(y);%Transformada de Fourier.
Y=Y/(Tam/2);%Adaptação na Amplitude.
plot(f(1:Tam/2),abs(Y(1:Tam/2)));%Plotagem do grafico com o primeiro filtro.

%FILTRO BUTTERWORTH
fc=1000;%Frequencia de corte.
fnormalizada=(2*fc)/fa;%Frequencia de corte normalizada.
[b1,a1]=butter(15,fnormalizada);%Aplicando o filtro butterworth.
[H1,W1]=freqz(b1,a1,Tam,fa);%Invertendo a resposta em frequencia.
hold on;%Plotar no grático sem fechar o anterior.
plot(W1,abs(H1));%Plotagem do filtro butterworth.
figure;

z=filter(b1,a1,y);%Filtrando o sinal.
Z=fft(z);%Transformada de Fourier.
Z=Z/Tam;%Adaptação da Amplitude.
plot(f(1:Tam/2),abs(Z(1:Tam/2)));%Plotagem do gráfico com o resultado do filtro FIR1.
audiowrite('C:\Users\Administrador\Downloads\audio_filtrado_iir.wav',z,fa);%Gravar o audio do resultado em um arquivo *wav.

%RESPOSTA AO IMPULSO
[HRimp,WRimp]=impz(b1,a1);%Função que calcula resposta ao impulso.
plot(WRimp,abs(HRimp));%Plotagem do grafico com resposta ao impulso.

sound(z,fa);%executa o arquivo de audio.