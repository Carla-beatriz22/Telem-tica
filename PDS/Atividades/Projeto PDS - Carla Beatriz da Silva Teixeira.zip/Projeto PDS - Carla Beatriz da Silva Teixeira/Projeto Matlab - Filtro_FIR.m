%Código Carla Beatriz 2024
%Projeto de Filtros Digitais FIR

pkg load signal;
[x,fa]=audioread('C:\Users\Administrador\Downloads\fala_sirene_tm3.wav');%carrega o arquivo de audio.
sound(x,fa);%executa o arquivo de audio.
figure;
plot(x);%Plotagem do vetor.

X=fft(x);%transformada do vetor X.
Tam=length(X);%tamanho do vetor X.
X=X/(Tam/2);%normalização do vetor.
f=[0:Tam-1]*fa/(Tam-1);%Criando o vetor da frequencia.
plot(f(1:Tam/2),abs(X(1:Tam/2)));%Plotagem do vetor.

%FILTRO NOTCH
omegac=(2*pi*250)/fa;%Normalizando a frequencia de corte.
r=0.996;%Qualidade do sinal.
b=[1 -2*cos(omegac) 1];%Coeficiente do numerador.
a=[1 -2*r*cos(omegac) r^2];%Coeficiente do denominador.
hold on;%Plotar no gráfico sem fechar o anterior.
[H,W]=freqz(b,a,Tam,fa);%Resposta em frequencia do filtro Notch.
plot(W,abs(H));%Plotagem do filtro Notch.