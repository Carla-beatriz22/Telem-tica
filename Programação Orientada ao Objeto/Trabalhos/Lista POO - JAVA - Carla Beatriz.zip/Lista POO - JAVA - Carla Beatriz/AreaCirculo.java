import java.util.Scanner;
public class AreaCirculo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Insira o raio do c�rculo:");
		
		float raio = scan.nextFloat();
		float area = (float) (3.14 * (raio * raio)); // PI * r�
		
		System.out.println(area);
		scan.close();
	}

}
