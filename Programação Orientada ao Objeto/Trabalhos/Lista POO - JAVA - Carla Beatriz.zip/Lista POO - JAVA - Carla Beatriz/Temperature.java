import java.util.Scanner;
public class Temperature {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Insira uma temperatura em Celsius para ser convertido para Fahrenheit:");
		float c = scan.nextFloat();
		
		float f = (float) (c * 1.8 + 32);
		
		System.out.println(f + " �F");
		scan.close();
	}

}
