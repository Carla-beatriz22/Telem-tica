import java.util.Scanner;

public class QuadradoCubo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Insira um n�mero para descobrir o quadrado e o cubo do mesmo:");
		float x = scan.nextFloat();
		
		float quadrado = x * x;
		float cubo = x * x * x;
		
		System.out.println("Quadrado: " + quadrado + "\nCubo: " + cubo);
		scan.close();
	}

}
