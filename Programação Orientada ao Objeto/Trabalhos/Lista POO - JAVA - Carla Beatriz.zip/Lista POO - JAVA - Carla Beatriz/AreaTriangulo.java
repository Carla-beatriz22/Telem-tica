import java.util.Scanner;

public class AreaTriangulo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Insira a base do tri�ngulo:");
		float b = scan.nextFloat();
		
		System.out.println("Insira a altura do tri�ngulo:");
		float h = scan.nextFloat();
		
		float area = (b * h)/2;
		
		System.out.println(area);
		scan.close();

	}

}
