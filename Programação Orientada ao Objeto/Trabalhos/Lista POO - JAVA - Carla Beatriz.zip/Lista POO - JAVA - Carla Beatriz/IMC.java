import java.util.Scanner;

public class IMC {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Insira seu peso(kg):");
		float m = scan.nextFloat();
		
		System.out.println("Insira sua altura(m):");
		float h = scan.nextFloat();
		
		float imc = m /(h * h);
		
		System.out.println("IMC: " + imc);
		scan.close();

	}

}
