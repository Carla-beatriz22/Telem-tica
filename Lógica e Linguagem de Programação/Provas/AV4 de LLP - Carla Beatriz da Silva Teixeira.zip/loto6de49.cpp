#include<stdio.h>
#include<locale.h>
#include<time.h>
#include<stdlib.h>
#include<conio.h>
void ordenar(int x[], int n)
{
    int aux,posicao,j,i;
    for(j=0; j<(n-1); j++)
    {
        posicao=j;
        for(i=j+1; i<n; i++)
            if(x[i]<x[posicao])
                posicao=i;
        aux=x[j];
        x[j]=x[posicao];
        x[posicao]=aux;
    }
}
void Loto(void)
{
    FILE *arquivo;
    int i,x[6],y[1],repetiu=1,j,k;
    srand(time(NULL));
    while(repetiu)
    {
        for(k=0; k<1; k++)
            y[k]=rand()%9;
        for(i=0; i<6; i++)
            x[i]=1+(rand()%49);
        for(repetiu=0,i=0; i<5; i++)
            for(j=i+1; j<6; j++)
                if(x[i]==x[j])
                    repetiu=1;
    }
    ordenar(x,6);
    printf("\nJogo gerado\n");
    printf("N�meros principais:");
    for(i=0; i<6; i++)
        printf("%3d ",x[i]);
    printf("\n\n");
    printf("Superzahl:");
    for(k=0; k<1; k++)
        printf("%2d",y[k]);


    if((arquivo=fopen("loto6de49.txt","w"))==NULL)
        printf("Erro na cria��o do arquivo!\n");
    else
    {
        for(i=0; i<6; i++)
            fprintf(arquivo,"%4d",x[i]);
        fprintf(arquivo,"\n\n");
        for(k=0; k<1; k++)
            fprintf(arquivo,"%4d",y[k]);
    }
}
main()
{
    setlocale(LC_ALL,"Portuguese");
    printf("Este programa gera um jogo simples da Loto 6/49 (Alemanha) e grava num arquivo texto: loto_6de49.txt.\n");
    printf("O jogador escolhe 6 n�meros de 1 a 49, e um n�mero extra chamado de 'Superzahl' de 0 a 9.\n");
    printf("O 'Superzahl' � Este � sorteado de um conjunto de n�meros � parte, logo ap�s o sorteio dos n�meros principais.\n");
    printf("Para ganhar o pr�mio principal � preciso acertar os seis n�meros principais e o n�mero extra Superzahl. \n");
    printf("A loteria possui nove faixas de premia��o.\n");
    printf("Para verificar sua pontua��o execute o programa verificador_6de49.c\n");
    Loto();
}

