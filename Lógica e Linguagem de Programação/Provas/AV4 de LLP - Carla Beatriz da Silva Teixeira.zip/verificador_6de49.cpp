#include<stdio.h>
#include<locale.h>
#include<time.h>
#include<stdlib.h>
#include<conio.h>
main()
{
    int i,x[6],y[1],resultado[6],super[1],pontos=0,j,k;
    FILE *arquivo;
    setlocale(LC_ALL,"Portuguese");
    if((arquivo=fopen("loto6de49.txt","r"))==NULL)
        printf("Erro na leitura do arquivo!\n");
    else
    {
        for(i=0; i<6; i++)
            fscanf(arquivo,"%6d",&x[i]);
        for(k=0; k<1; k++)
            fscanf(arquivo,"%d",&y[k]);
    }

    printf("Este programa verifica quantos pontos foram feitos na Loto 6/49 (Alemanha).\n");
    printf("O arquivo jogo.txt tem o seguinte jogo armazenado\n");
    printf("\nVetor armazenado\n");
    printf("N�meros principais:");
    for(i=0; i<6; i++)
        printf("%3d ",x[i]);
    printf("\n\n");
    printf("Superzahl:");
    for(k=0; k<1; k++)
        printf("%2d",y[k]);

    printf("\nDigite o resultado oficial na Loto 6/49 (Alemanha)\n");
    for(i=0; i<6; i++)
        scanf("%d",&resultado[i]);
    for(k=0; k<1; k++)
    {
        printf("Digite o Superzahl:");
        scanf("%d",&super[k]);
    }

    printf("\nO resultado oficial na Loto 6/49 (Alemanha) foi:\n");
    printf("N�meros principais:");
    for(i=0; i<6; i++)
        printf("%6d",resultado[i]);
    printf("\n\n");
    printf("Superzahl:");
    for(k=0; k<1; k++)
        printf("\n%2d",super[k]);

    for(i=0; i<6; i++)
        for(j=0; j<6; j++)
            for(k=0; k<1; k++)
                if(x[i]==resultado[j])
                    pontos++;
    			if(y[0] == super[0]) {
						printf("\n\n Voc� acertou %d n�meros e o Superzahl.\n",pontos);
    				} else if (y[0]!=super[0])
    				printf("\n\n Voc� acertou %d n�meros e n�o acertou o Superzahl.\n",pontos);
    printf("\nFim.\n");
}
